package io;

public class HtmlReportWriter extends ReportWriter {
    @Override
    protected Report createReport() {
        return new HtmlReport();
    }
}