package io;

public class TxtReportWriter extends ReportWriter {
    @Override
    protected Report createReport() {
        System.out.println("its workinggggg");
        return new TxtReport();
    }
}